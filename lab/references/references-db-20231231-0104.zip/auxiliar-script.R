# TODO:   Auxiliar script for managing the backup process
# 
# Author: Miguel Alvarez
################################################################################

library(backpackR)

release_project(project = "lab/references/project-1", path = "lab/references")

## build_db(path = "lab/references", dbname = "references-db", port = "5433",
##     overwrite = TRUE)
